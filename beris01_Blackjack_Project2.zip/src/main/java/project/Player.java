package project;
import java.util.ArrayList;

public class Player {
	static Deck deck;
	ArrayList<Card> hand;
	private int wins;
	
	Player() {
		hand= new ArrayList();
		wins=0;
		deck= new Deck();
	}
	
	ArrayList<Card> getHand() {
		return hand;
	}
	
	int valueOfHand() {
		int value= 0;
		for(Card card: hand) {
			if(!card.getFace().equals("A"))
				value+= card.valueOf();
			else {
				value+= value+11>21? 1 : 11;
			}
		}
		return value;
	}
	
	void clearHand() {
		hand.clear();
	}
	
	boolean stand(int otherPlayerValue) {
		double rand= Math.random();
		int value= valueOfHand();
		return value==21 || (value>=16 && value>otherPlayerValue) || 
				(value==otherPlayerValue && rand>=0.5 && value>=16)? true : false;
	}
	
	boolean busted() {
		return valueOfHand() > 21;
	}
	
	void hit() {
		hand.add(deck.dealCard());
	}
	
	int win() {
		return ++wins;
	}
}
 